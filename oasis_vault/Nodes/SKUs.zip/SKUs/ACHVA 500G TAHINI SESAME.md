---
type: SKU
department: "[[COOKING SAUCE-PASTE]]"
supplier: "[[PASAGOT LIMITED SR]]"
price: 37.36682242990654
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# ACHVA 500G TAHINI SESAME

## Relationships
- **Department**: [[COOKING SAUCE-PASTE]]
- **Supplier**: [[PASAGOT LIMITED SR]]

## Potential Substitutes
- [substitution]:: [[SANTA MARIA 70G TOMATO PASTE SATCHET]]
- [substitution]:: [[KENYLON 275G TOMATO PASTE EOT]]
- [substitution]:: [[KENYLON TOMATO PASTE 100G]]
- [substitution]:: [[PEP 70G TOMATO PASTE POUCH]]
- [substitution]:: [[KENYLON 70G TOMATO PASTE SACHETS]]

## Network Insights
- [upstream_supply]:: [[PASAGOT LIMITED SR]]
- [downstream_demand]:: [[Retail Market]]
