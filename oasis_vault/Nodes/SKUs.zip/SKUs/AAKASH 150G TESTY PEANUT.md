---
type: SKU
department: "[[INDIAN FOOD-SNACKS-SWEETS]]"
supplier: "[[Unknown]]"
price: 190.2579299132948
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# AAKASH 150G TESTY PEANUT

## Relationships
- **Department**: [[INDIAN FOOD-SNACKS-SWEETS]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[SWAMINARAYAN 500G FARAYALI  ATTA]]
- [substitution]:: [[KURKURE 50G MASALA MUNCH]]
- [substitution]:: [[AAKASH 25G SHOOL MASTI]]
- [substitution]:: [[LAYS 28G CREAM&ONION WAFERS]]
- [substitution]:: [[LAYS 28G INDIAN MAGIC MASALA]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
