---
type: SKU
department: "[[TETRA PACK JUICE]]"
supplier: "[[Unknown]]"
price: 87.80460441720695
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 PAN AROMA MEDITERRANEAN ORCHARD GLASS CANDLES#PAN0678

## Relationships
- **Department**: [[TETRA PACK JUICE]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[RIBENA 250ML BLACKCURRANT]]
- [substitution]:: [[RIBENA 250ML BC&STRAWBERRY]]
- [substitution]:: [[PICK N PEEL 250ML MANGO]]
- [substitution]:: [[PICK N PEEL 250ML TROPICAL MIX]]
- [substitution]:: [[LUCOZADE 250ML BOOST TETRA]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
