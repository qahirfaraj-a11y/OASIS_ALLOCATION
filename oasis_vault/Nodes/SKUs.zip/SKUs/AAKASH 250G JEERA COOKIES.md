---
type: SKU
department: "[[BISCUITS]]"
supplier: "[[RAJ KAMAL ENTERPRISE LIMITED]]"
price: 68.7140294223179
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# AAKASH 250G JEERA COOKIES

## Relationships
- **Department**: [[BISCUITS]]
- **Supplier**: [[RAJ KAMAL ENTERPRISE LIMITED]]

## Potential Substitutes
- [substitution]:: [[OREO 55.2G ORIGINAL COOKIES]]
- [substitution]:: [[OREO 31.3G ENROBED]]
- [substitution]:: [[MANJI 45G MILKSTAR BISCUITS]]
- [substitution]:: [[FRESKA 17G WAFER CHOCOLATE COATED]]
- [substitution]:: [[MCVITIES 400G DIGESTIVE BISCUIT]]

## Network Insights
- [upstream_supply]:: [[RAJ KAMAL ENTERPRISE LIMITED]]
- [downstream_demand]:: [[Retail Market]]
