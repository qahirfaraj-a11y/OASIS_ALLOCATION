---
type: SKU
department: "[[SWEETS]]"
supplier: "[[Unknown]]"
price: 15.725170194217965
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 ESC1002 FOOT SOAK SPEARMINT & MENTHOL 450G

## Relationships
- **Department**: [[SWEETS]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[MR.BERRYS KING KUBWA XXL STRAWBERRY LOLLIPOP]]
- [substitution]:: [[MR.BERRYS KING KUBWA XXL PASSION LOLLIPOP]]
- [substitution]:: [[MR.BERRYS KING KUBWA XXL TONGUE PAINTER LOLLIPOP]]
- [substitution]:: [[KSL TROPICAL LOLLIPOP SINGLES]]
- [substitution]:: [[CHUPA CHUPS ASST LOLLIPOP]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
