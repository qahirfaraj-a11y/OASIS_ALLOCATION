---
type: SKU
department: "[[SPICES]]"
supplier: "[[Unknown]]"
price: 209.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 PAN0403 APPLE & CINNAMON 16 TEA LIGHTS CANDLES

## Relationships
- **Department**: [[SPICES]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[TROP HEAT 100G PAPRIKA JAR]]
- [substitution]:: [[TROP HEAT 100G TURMERIC GRND JAR]]
- [substitution]:: [[TROP HEAT 100G GARLIC POWDER]]
- [substitution]:: [[TROP HEAT 100G CINNAMON GRND]]
- [substitution]:: [[TROP HEAT 100G GINGER GRND JAR]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
