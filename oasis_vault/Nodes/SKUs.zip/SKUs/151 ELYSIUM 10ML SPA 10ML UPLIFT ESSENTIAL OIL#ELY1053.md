---
type: SKU
department: "[[COOKING OIL]]"
supplier: "[[Unknown]]"
price: 1155.614778397909
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 ELYSIUM 10ML SPA 10ML UPLIFT ESSENTIAL OIL#ELY1053

## Relationships
- **Department**: [[COOKING OIL]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[RINA 5LT VEGETABLE OIL]]
- [substitution]:: [[RINSUN 3LT SUNFLOWER OIL]]
- [substitution]:: [[RINSUN 1LT SUNFLOWER OIL]]
- [substitution]:: [[FRESH FRI 250ML COOKING OIL]]
- [substitution]:: [[RINA 1LT VEGETABLE OIL JERRICAN]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
