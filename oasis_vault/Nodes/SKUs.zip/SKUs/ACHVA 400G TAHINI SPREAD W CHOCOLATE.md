---
type: SKU
department: "[[CHOCOLATES]]"
supplier: "[[PASAGOT LIMITED SR]]"
price: 167.07607962213226
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# ACHVA 400G TAHINI SPREAD W CHOCOLATE

## Relationships
- **Department**: [[CHOCOLATES]]
- **Supplier**: [[PASAGOT LIMITED SR]]

## Potential Substitutes
- [substitution]:: [[TWIX TWIN BAR 50G]]
- [substitution]:: [[SNICKERS SINGLE BAR 50G]]
- [substitution]:: [[NESTLE 41.5G KITKAT 4 FINGER MILK]]
- [substitution]:: [[MARS SINGLE BARS 51G]]
- [substitution]:: [[SNICKERS 40G SINGLE CHOCO BAR]]

## Network Insights
- [upstream_supply]:: [[PASAGOT LIMITED SR]]
- [downstream_demand]:: [[Retail Market]]
