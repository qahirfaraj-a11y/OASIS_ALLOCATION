---
type: SKU
department: "[[PET ASSESORIES]]"
supplier: "[[Unknown]]"
price: 950.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 FLEA AND TICK COLLAR FOR CATS PG008

## Relationships
- **Department**: [[PET ASSESORIES]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[FLOWER VALUE 1LT DOG SHAMPOO]]
- [substitution]:: [[FERPLAST DOG COLLAR CLB C15-44 - 925 BLUE]]
- [substitution]:: [[ARLA 200G APETINA ORG WHT CHEESE CUBES IN BRINE]]
- [substitution]:: [[PMS EAZEE 2 CLEAN OCEAN CLEANING CATRIDGE PMS825046]]
- [substitution]:: [[PROLINE 5LT CLUMPING CAT LITTER ALOEVERA]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
