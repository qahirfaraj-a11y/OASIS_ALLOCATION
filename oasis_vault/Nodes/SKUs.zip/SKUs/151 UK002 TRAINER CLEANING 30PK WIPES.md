---
type: SKU
department: "[[WIPES]]"
supplier: "[[Unknown]]"
price: 179.21210061182867
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 UK002 TRAINER CLEANING 30PK WIPES

## Relationships
- **Department**: [[WIPES]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[HANAN FLUSHABLE WATER WIPES 72PCS]]
- [substitution]:: [[PAMPERS BABY WIPES SENSITIVE 56S]]
- [substitution]:: [[VELVEX ANTIBACTERIAL WET WIPES 10S]]
- [substitution]:: [[HANAN ANTI-BACTERIAL WIPES 80S]]
- [substitution]:: [[BELLA BABY WIPES 80S]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
