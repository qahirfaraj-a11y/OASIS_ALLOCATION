---
type: SKU
department: "[[HAIR PRODUCTS]]"
supplier: "[[SLEEK KENYA  LIMITED SR]]"
price: 1330.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# AFRICAN PRIDE OM GROWTH OIL 8OZ

## Relationships
- **Department**: [[HAIR PRODUCTS]]
- **Supplier**: [[SLEEK KENYA  LIMITED SR]]

## Potential Substitutes
- [substitution]:: [[GOODKNIGHT 600ML MIK AEROSOL]]
- [substitution]:: [[CON 7OZ ARGAN OIL FOAM MOUSSE]]
- [substitution]:: [[ORS 207ML SUPER SOFT STYLE CURL D-MOUSE]]
- [substitution]:: [[CANTU 340G DEEP TREATMENT MASQUE]]
- [substitution]:: [[ORS 227G SUPER NOURISHING DAILY CURL CREME]]

## Network Insights
- [upstream_supply]:: [[SLEEK KENYA  LIMITED SR]]
- [downstream_demand]:: [[Retail Market]]
