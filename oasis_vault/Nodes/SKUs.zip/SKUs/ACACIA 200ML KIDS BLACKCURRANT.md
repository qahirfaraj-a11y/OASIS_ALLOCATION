---
type: SKU
department: "[[READY TO DRINK]]"
supplier: "[[KEVIAN KENYA LTD]]"
price: 111.55312357698352
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# ACACIA 200ML KIDS BLACKCURRANT

## Relationships
- **Department**: [[READY TO DRINK]]
- **Supplier**: [[KEVIAN KENYA LTD]]

## Potential Substitutes
- [substitution]:: [[ACACIA 200ML KIDS BLUE RASPBERRY]]
- [substitution]:: [[MINUTE MAID 1L PULPY ORANGE]]
- [substitution]:: [[ACACIA 200ML KIDS APPLE]]
- [substitution]:: [[MINUTE MAID 400ML MANGO JUICE]]
- [substitution]:: [[ACACIA 200ML KIDS MANGO]]

## Network Insights
- [upstream_supply]:: [[KEVIAN KENYA LTD]]
- [downstream_demand]:: [[Retail Market]]
