---
type: SKU
department: "[[AIR FRESHNERS]]"
supplier: "[[Unknown]]"
price: 295.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 190G PURE JASMINE AIR FRESHENER#PAN0552

## Relationships
- **Department**: [[AIR FRESHNERS]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[FRESH DAY 360ML AIR FRESHENER LAVENDER]]
- [substitution]:: [[VELVEX 300ML AIR FRESHENER CITRUS]]
- [substitution]:: [[VELVEX 300ML AIR FRESHENER POTPOURRI]]
- [substitution]:: [[LOVING IT 300ML STRAWBERRY AIR FRESHNER]]
- [substitution]:: [[VELVEX 300ML AIR FRESHNER MOUNTAIN LAKE]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
