---
type: SKU
department: "[[WINES]]"
supplier: "[[VERUM DIMENSIONS LIMITED SR]]"
price: 1679.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 99 ROSA 750ML ROSE WINE

## Relationships
- **Department**: [[WINES]]
- **Supplier**: [[VERUM DIMENSIONS LIMITED SR]]

## Potential Substitutes
- [substitution]:: [[BRANCOTT 750ML ESTA SAUV BLANC]]
- [substitution]:: [[FRESCHELLO EXTRA DRY SPARKLING WINE 750ML]]
- [substitution]:: [[JACOBS CREEK CHARDONNAY 750ML]]
- [substitution]:: [[PIERRE MARCEL 750ML SWEET RED]]
- [substitution]:: [[TALL HORSE CABERNET SAUVIGNON 750ML]]

## Network Insights
- [upstream_supply]:: [[VERUM DIMENSIONS LIMITED SR]]
- [downstream_demand]:: [[Retail Market]]
