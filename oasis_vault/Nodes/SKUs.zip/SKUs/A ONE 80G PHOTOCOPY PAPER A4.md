---
type: SKU
department: "[[STATIONARIES]]"
supplier: "[[PAPER SYSTEMS LTD]]"
price: 50.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# A ONE 80G PHOTOCOPY PAPER A4

## Relationships
- **Department**: [[STATIONARIES]]
- **Supplier**: [[PAPER SYSTEMS LTD]]

## Potential Substitutes
- [substitution]:: [[ANDEGO 3G SUPER GLUE]]
- [substitution]:: [[TEEPEE PVC EXECUTIVE SPRING FILE 115]]
- [substitution]:: [[PELIKAN ERASER BR 80]]
- [substitution]:: [[ROK CLEAR TAPES 18MMX50MTRS S40]]
- [substitution]:: [[AZHAR 80G PHOTOCOPY PAPER A4]]

## Network Insights
- [upstream_supply]:: [[PAPER SYSTEMS LTD]]
- [downstream_demand]:: [[Retail Market]]
