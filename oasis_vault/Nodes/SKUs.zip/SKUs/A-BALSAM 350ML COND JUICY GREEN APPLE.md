---
type: SKU
department: "[[SHAMPOOS-CONDITIONER]]"
supplier: "[[TRADE ROOTS LTD]]"
price: 1075.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# A/BALSAM 350ML COND JUICY GREEN APPLE

## Relationships
- **Department**: [[SHAMPOOS-CONDITIONER]]
- **Supplier**: [[TRADE ROOTS LTD]]

## Potential Substitutes
- [substitution]:: [[LOREAL ELVIVE 400ML SHAMP COLOUR PROTECT]]
- [substitution]:: [[H&S 400ML CLASSIC CLEAN SHAMPOO]]
- [substitution]:: [[DABUR 150G HERBAL TPASTE CLOVE VALUE PACK]]
- [substitution]:: [[LOREAL PARIS 400ML ELVIVE SHAMPOO FALL RESIST]]
- [substitution]:: [[CLEAR DISPLAY BOOK 40POCKETS]]

## Network Insights
- [upstream_supply]:: [[TRADE ROOTS LTD]]
- [downstream_demand]:: [[Retail Market]]
