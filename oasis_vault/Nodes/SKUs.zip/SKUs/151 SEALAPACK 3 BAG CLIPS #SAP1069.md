---
type: SKU
department: "[[STATIONARIES]]"
supplier: "[[Unknown]]"
price: 50.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 151 SEALAPACK 3 BAG CLIPS #SAP1069

## Relationships
- **Department**: [[STATIONARIES]]
- **Supplier**: [[Unknown]]

## Potential Substitutes
- [substitution]:: [[ANDEGO 3G SUPER GLUE]]
- [substitution]:: [[TEEPEE PVC EXECUTIVE SPRING FILE 115]]
- [substitution]:: [[PELIKAN ERASER BR 80]]
- [substitution]:: [[ROK CLEAR TAPES 18MMX50MTRS S40]]
- [substitution]:: [[AZHAR 80G PHOTOCOPY PAPER A4]]

## Network Insights
- [upstream_supply]:: [[Unknown]]
- [downstream_demand]:: [[Retail Market]]
