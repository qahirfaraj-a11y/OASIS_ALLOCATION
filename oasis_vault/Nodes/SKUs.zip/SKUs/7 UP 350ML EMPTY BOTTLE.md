---
type: SKU
department: "[[EMPTIES-CRATES]]"
supplier: "[[SBC KENYA LIMITED]]"
price: 15.0
margin_pct: 0
revenue: 0
gross_profit: 0
sales_rank: 9999
---

# 7 UP 350ML EMPTY BOTTLE

## Relationships
- **Department**: [[EMPTIES-CRATES]]
- **Supplier**: [[SBC KENYA LIMITED]]

## Potential Substitutes
- [substitution]:: [[COCA COLA 300ML EMPTY BOTTLE]]
- [substitution]:: [[COKE ZERO SUGAR 300ML EMPTY BOTTLE]]
- [substitution]:: [[SPRITE 300ML EMPTY BOTTLE]]
- [substitution]:: [[SHWEPPES SODA WATER 300ML EMPTY BOTTLE]]
- [substitution]:: [[FANTA ORANGE 300ML EMPTY BOTTLE]]

## Network Insights
- [upstream_supply]:: [[SBC KENYA LIMITED]]
- [downstream_demand]:: [[Retail Market]]
